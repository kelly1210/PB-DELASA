#!/bin/sh

python /home/data2/dong_keke/software/PB-DELASA_v/bin/monitor/./pyflowDEL.py --caseFq /home/data2/dong_keke/software/PB-DELASA_v/example/NGS001/01.Trim//S1_R1.fastq.gz,/home/data2/dong_keke/software/PB-DELASA_v/example/NGS001/01.Trim//S1_R2.fastq.gz -c /home/data2/dong_keke/software/PB-DELASA_v/test1/config/S1.config.txt -p S1 -o /home/data2/dong_keke/software/PB-DELASA_v/example/NGS001 -s /home/data2/dong_keke/software/PB-DELASA_v/test1/sample_info.txt -l /home/data2/dong_keke/software/PB-DELASA_v/lib/library_info.txt
    
